# Agent integration

Add the following instruction to the coding agent's repository rules (for example, `AGENTS.md`, `CLAUDE.md`, Cursor project rules, or the equivalent used by your agent):

> Before making UI or frontend changes, read `tools/design-guard/SKILL.md` and `design-guard.config.json`. Treat the skill as the project's design and implementation standard. Inspect the existing project and preserve working behaviour before editing. Research relevant mature products before significant new interface work. After implementation, run `npm run design:audit`, the project's normal lint/type/test/build commands, and `npm run design:browser` against the running application. Inspect every screenshot generated in `.design-guard/screenshots`, complete `.design-guard/VISUAL-REVIEW.md`, and test the primary user journey. Fix violations instead of weakening rules or suppressing findings. Do not claim visual review, browser testing, research, or interaction testing unless it was actually performed. A green build is not design approval.

## Expected completion response from the agent

The agent should report:

1. What changed and which user task it supports.
2. The main design decisions and any references consulted.
3. Commands and tests actually run, with pass/fail outcomes.
4. Viewports and routes inspected, including links to screenshots or the generated report.
5. The main workflow exercised and the states tested.
6. Unresolved issues, justified exceptions, and anything not verified.

## Project-specific adaptation

The package is reusable, but every repository still needs correct `sourcePatterns`, approved design tokens, routes, and a local development URL. Do not copy another project's colour palette or route list blindly. The user owns approval of design exceptions.
