# Design Guard

A reusable, framework-agnostic quality gate for frontend projects and coding agents. It pairs a human-readable design skill with automated static checks, responsive browser checks, accessibility scanning, screenshots, and a mandatory manual visual-review checklist.

**Important:** Design Guard detects measurable patterns. It cannot decide on its own whether a page is tasteful, whether a card is justified, or whether a layout fits the product. Those decisions remain part of the visual-review gate.

## What it checks

### Static source audit

- CSS Grid declarations (blocked by default; Flexbox is the default preference).
- Gradients, backdrop blur/glassmorphism, decorative box shadows, text glow, and drop shadows.
- Unapproved raw colour literals in CSS and common frontend source files.
- Font families outside the configured allowlist and projects using too many font families.
- Suspicious card/Bento class names (warning only; cards are allowed when appropriate).
- Inline styles (warning only; dynamic styles may be justified).
- Repeated horizontal padding values across multiple selectors (heuristic warning).

### Browser audit

- Screenshots at mobile portrait/landscape, tablet portrait/landscape, laptop, desktop, and ultrawide sizes.
- Horizontal overflow detection.
- Uncaught page errors.
- axe-core accessibility violations.
- A generated manual visual-review checklist linked to the screenshots.

## Requirements

- Node.js 20 or newer.
- For browser checks: Playwright, `@axe-core/playwright`, and a Chromium browser installed in the target project.

## Install into any project

Copy this `design-guard` folder into the target repository, for example:

```text
your-project/
  tools/
    design-guard/
```

Then install it as a local development dependency from the repository root:

```bash
npm install --save-dev ./tools/design-guard
npx design-guard init
```

This works independently of whether the application uses React, Vue, Svelte, Next.js, Vite, or plain HTML/CSS. Update `sourcePatterns` in the generated config to match the repository's structure.

Add convenient scripts to the application's `package.json`:

```json
{
  "scripts": {
    "design:audit": "design-guard audit",
    "design:browser": "design-guard browser",
    "design:check": "design-guard check --browser"
  }
}
```

For browser checks, install the optional tools in the target project:

```bash
npm install --save-dev playwright @axe-core/playwright
npx playwright install chromium
```

Start the application in another terminal, then run:

```bash
npm run design:audit
npm run design:browser
# Or run both gates:
npm run design:check
```

## Configure the project

`design-guard init` creates `design-guard.config.json` and a top-level `DESIGN-REVIEW.md` checklist. Configure at least:

- `projectName`: human-readable project name.
- `sourcePatterns`: files and directories to inspect.
- `approvedColors`: the complete approved palette values (keep this list aligned with the tokens defined in `tokenFiles`). Raw values found outside token files must belong to this list; consumers should reference CSS variables.
- `tokenFiles`: files that define the canonical tokens and are therefore exempt from raw-colour checks.
- `allowedFontFamilies` and `maxFontFamilies`: typography policy.
- `browser.baseUrl` and `browser.paths`: local development URL and routes to exercise.
- `rules`: turn a rule off or change its severity only when the project explicitly authorizes an exception.

Colour literals in token-definition files are exempt when those files are listed in `tokenFiles`; consumers should reference the tokens. CSS `var(--token-name)` references are not treated as raw colour literals.

Example token setup:

```json
{
  "tokenFiles": ["src/styles/tokens.css"],
  "approvedColors": ["#16324f", "#ffffff"],
  "allowedFontFamilies": ["Manrope", "Inter"],
  "maxFontFamilies": 2
}
```

The allowlist contains families permitted by the project, not a recommendation to use every family. The audit still enforces the configured maximum. Keep `approvedColors` as the canonical palette inventory even when those values are stored only inside token files; this is how the configured palette limit is enforced.

## Commands

```bash
design-guard init [--config path]
design-guard audit [--config path] [--json] [--fail-on warning|error]
design-guard browser [--config path] [--url http://localhost:3000]
design-guard check [--config path] [--browser] [--url http://localhost:3000]
```

- `audit` writes `.design-guard/static-report.json`.
- `browser` writes screenshots to the configured folder (default `.design-guard/screenshots`), a JSON report, and `.design-guard/VISUAL-REVIEW.md`.
- `check --browser` runs both static and browser gates.
- Exit code `0` means no blocking finding under the selected threshold; `1` means configured violations; `2` means setup or runtime failure.

## CI example

A minimal GitHub Actions job can run the static gate on every pull request. Add browser testing after your normal application build/start process is available.

```yaml
name: Design quality
on: [pull_request]
jobs:
  static-design-audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22
          cache: npm
      - run: npm ci
      - run: npm run design:audit
```

## Suppressing a justified exception

Avoid disabling rules globally. Add a narrow entry in `suppressions` only when an exception is justified and approved:

```json
{
  "suppressions": [
    {
      "rule": "no-decorative-shadows",
      "file": "src/components/Popover.css",
      "reason": "Approved elevation is needed to separate this transient menu from the page.",
      "expires": "2027-01-31"
    }
  ]
}
```

A suppression needs a reason of at least eight characters. Expired suppressions stop applying. Review suppressions regularly; do not use them to hide design debt.

## Important limitations

Static checks are intentionally conservative:

- A class containing `card` or `bento` is only a warning. The tool cannot know whether a card is appropriate without understanding the page and content.
- Repeated horizontal padding is a heuristic. Shared safe gutters can be valid; the warning asks the reviewer to check for compounded nested padding.
- Colour detection focuses on literal hex, RGB, HSL, and HWB values in scanned files. It cannot identify every colour produced by images, canvas, runtime JavaScript, or external stylesheets.
- Browser screenshots and overflow checks cannot certify that hierarchy, copy, visual balance, or interaction design are good.
- axe-core cannot find every accessibility problem. Manual keyboard and assistive-technology review is still needed.
- The browser command captures configured routes and viewport sizes; it does not invent or discover the product's complete user journeys. Add Playwright end-to-end tests for critical workflows.

## Recommended agent workflow

1. Read `SKILL.md` before designing or editing.
2. Inspect the repository and identify the existing design tokens and user journeys.
3. Research comparable, mature products when the task involves significant new UI.
4. Implement only the requested scope and preserve existing behaviour.
5. Run the static audit, lint, type checks, tests, and build.
6. Start the app and run browser checks.
7. Open every generated screenshot and complete `.design-guard/VISUAL-REVIEW.md`.
8. Exercise the primary workflow and important error/recovery states.
9. Fix failures; do not weaken the rules simply to make the report green.
10. Report exactly what was tested and any remaining limitations.

## Package files

- `SKILL.md` — reusable agent design and implementation standard.
- `AGENT-INTEGRATION.md` — instruction snippet for connecting the skill to coding agents.
- `design-guard.config.json` — generated per-project policy.
- `src/` — static and browser auditors.
- `bin/design-guard.js` — CLI entry point.
- `examples/` — example configuration and sample fixture.
