# Design Quality & Implementation Skill

## Mission

Deliver interfaces that are purposeful, usable, coherent, responsive, accessible, and appropriate to the product and page type. A successful build is not proof of a successful design. Treat this file as an execution standard, not optional inspiration.

The agent must inspect the existing project before changing it, learn its architecture and design system, preserve working behaviour, and make the smallest coherent set of changes that fully completes the requested task.

## Authority levels

- **FORBIDDEN:** Do not introduce the pattern unless the user explicitly authorizes an exception. Examples include unapproved colours, decorative gradients, glassmorphism, glow effects, unnecessary shadows, and CSS Grid in projects that retain the default Flexbox preference.
- **REQUIRED:** Must be done where applicable. Examples include responsive checks, meaningful interaction states, page-appropriate structure, and testing the key user journey.
- **CONTEXTUAL:** Requires judgement. Examples include cards, borders, animation, tables, and complex panels. Use them only when they solve a real content or interaction need.

When instructions conflict, follow the user's latest explicit direction. Do not silently reinterpret a FORBIDDEN rule as a suggestion.

## 1. Understand before building

1. Read the project instructions, package scripts, dependencies, routes, component structure, design tokens, existing tests, and relevant screens before editing.
2. Identify the requested outcome, intended users, primary task, content, states, and constraints.
3. Ask a concise clarifying question only when a missing fact blocks a sound implementation. Otherwise make a conservative, reversible decision and state the assumption.
4. Do not replace established architecture, libraries, naming conventions, or working components without a concrete reason.
5. Do not invent features, data, testimonials, ratings, stock levels, discounts, legal claims, or business policies.

## 2. Research and references

Before significant new interface work, research the actual interface category. Use mature products, established design systems, high-quality open-source projects, and relevant work from sources such as Dribbble, Behance, Pinterest, and Awwwards.

Research the task, not just the aesthetic. For example, an e-commerce flow should be compared with real stores and real checkout behaviour; a professional editor should be compared with established creative tools; a legal page should be compared with readable legal-document patterns.

Use references to understand hierarchy, information density, navigation, terminology, interaction patterns, and responsive behaviour. Do not copy a screenshot blindly. Do not claim research was done when it was not. Keep research notes short and record only decisions that affect the implementation.

## 3. Design from purpose

Every element must earn its place. For each section, card, control, icon, divider, badge, image, and animation, be able to explain:

- What user task or information need does it serve?
- Why is this layout appropriate here?
- What happens when the user interacts with it?
- What happens on a small screen and in empty, loading, disabled, or error states?

Do not add sections or UI simply to make a page look fuller. Do not confuse decoration with information architecture.

## 4. Reject generic AI-generated UI

Do not default to a generic hero plus three feature cards, a Bento grid, a row of statistics, oversized rounded cards, floating badges, decorative blobs, or a dashboard template. Use a card only when the content is an independently actionable or scannable unit that genuinely benefits from separation.

Do not place every paragraph, heading, metric, or content group inside a card. Do not turn documentation, terms, privacy policies, disclaimers, or long-form informational content into a product showcase.

Avoid arbitrary component creation and over-componentization. Reuse components when they represent a stable, repeated pattern, not merely because two pieces of markup look vaguely similar.

## 5. Layout, spacing, and page gutters

- Avoid applying identical horizontal padding to every DOM element or nesting multiple padded containers that compound the gutter.
- Maintain safe viewport margins and readable line lengths, but vary widths and alignment according to the content and hierarchy.
- Use full-width or edge-aligned elements where they serve the task; do not force everything into a narrow document column.
- Establish a deliberate spacing scale. Do not add arbitrary margin and padding values to patch alignment problems.
- Use Flexbox by default. Do not use CSS Grid unless the user has explicitly authorized it for the project or component.
- Avoid layouts with large empty areas, cramped content, repetitive rows, unnecessary separators, or inconsistent alignment.

## 6. Colour governance

- Use the project's established semantic colour tokens.
- Do not add random, pale, one-off, orphan, or arbitrary-opacity colours.
- New colours require a clear role and explicit approval before they become part of the palette.
- Aim for no more than two primary colours and four main palette colours unless the product's needs justify more and the user approves it.
- Status colours are allowed when they communicate real state, but they must be semantic and consistent.
- Do not use gradients, glow, or blur as decoration.
- Do not encode meaning with colour alone; pair colour with text, iconography, or another cue.

## 7. Typography

- Use no more than two font families unless there is a documented, approved reason.
- Preferred families include Manrope, Poppins, Space Grotesk, and Inter; use the project's established choice rather than adding all of them.
- Create hierarchy through size, weight, line height, and spacing, not arbitrary font changes.
- Keep body text readable. Avoid tiny labels, excessively wide paragraphs, compressed line-height, and oversized headings that crowd out the task.
- Do not use all caps or letter spacing indiscriminately.

## 8. Icons, imagery, and assets

- Prefer a consistent icon library such as Lucide or Font Awesome. Do not invent hand-drawn SVG illustrations.
- An icon must have a clear meaning; use a text label where an icon alone could be ambiguous.
- Use relevant, high-quality imagery with appropriate aspect ratios and intentional crops.
- Do not stretch images, use unrelated stock imagery, or add decorative imagery that competes with the task.
- Provide useful alternative text for meaningful images; mark purely decorative assets appropriately.

## 9. Navigation and information architecture

- Group navigation by user goals and mental models, not by internal code structure.
- Use labels users understand. Avoid unexplained jargon, vague labels, and ambiguous icon-only navigation.
- Keep primary navigation distinct from secondary, contextual, and account actions.
- Show location and active state clearly. Menus must support keyboard interaction and have sensible focus behaviour.
- Do not add nested navigation unless a real hierarchy exists. Avoid deep or confusing menu nesting.

## 10. Dropdowns and menus

- Size menus to their content and task. Do not create oversized surfaces with arbitrary padding or empty space.
- Position menus predictably relative to their trigger and keep them inside the viewport.
- Group related actions; separate destructive actions where appropriate.
- Provide visible hover, focus, selected, and disabled states.
- Close menus predictably on selection, Escape, and appropriate outside interaction. Do not let nested menus become difficult to operate.

## 11. UX writing and learnability

- Use plain, direct language. Every heading, label, button, and message must communicate what it means or what will happen.
- Avoid vague CTA labels such as “Continue” when the actual action can be named more clearly.
- Avoid buzzwords, filler, repetitive explanations, and unnecessary technical terminology.
- Use technical terms only when the audience needs them; explain them in context when necessary.
- Error messages should explain what happened and the next useful action. Empty states should explain what is absent and how to proceed.
- A user should not need documentation or a web search to understand ordinary product controls.

## 12. Page-specific structure

Choose layout according to the purpose of the page. Do not apply one template everywhere.

### Landing and marketing pages

Usually include a clear navigation, a focused hero with a specific value proposition and relevant action, only the sections needed to establish value and trust, and a purposeful footer. Do not insert arbitrary feature grids, testimonials, FAQs, or statistics when there is no real content to support them.

### About pages

Explain who operates the product, why it exists, what it does, and relevant people or history using real information. Do not make it a duplicate landing page filled with generic cards.

### Legal pages

Terms, privacy policies, disclaimers, and similar pages are documents, not product showcases. Use a readable document layout with clear title, effective or updated date where supplied, meaningful headings, numbered sections where appropriate, and a table of contents when the length warrants one. Avoid Bento layouts, generic cards, marketing widgets, and decorative components. Preserve the legal meaning; do not invent legal clauses or imply legal review that did not occur.

### Documentation and help pages

Organize around topics and tasks. Provide clear headings, navigable sections, examples, and related links where useful. Avoid marketing-page structures and generic card collections where a document hierarchy is clearer.

### Dashboards and admin tools

Prioritize workflow, scanability, data hierarchy, filters, and clear actions. Do not fill space with decorative statistics. Make data freshness, loading, empty, failure, permissions, and destructive actions clear.

### Forms and onboarding

Group fields by the user's mental model. Ask only for information needed at that step. Explain constraints and validation close to the field. Preserve entered values after recoverable errors. Clearly distinguish optional and required inputs.

## 13. E-commerce: design the whole journey

Treat the store as one connected system. Design and test the relevant journey across catalogue/listing, search, filters, sorting, active filter chips, product details, variants, seller information, cart, checkout, payment handoff, and order confirmation.

Product information, variant selection, price, stock, seller, delivery, cart totals, and checkout summary must remain consistent. Search, filters, chips, sorting, quantity changes, and variant controls must actually work. Do not invent ratings, reviews, availability, discounts, shipping promises, or payment success. Never initiate a real purchase or payment without explicit authorization.

## 14. Complex professional workspaces

For interfaces comparable to creative editors, IDEs, or operations consoles, use coherent docked toolbars and panels, grouped functions, deliberate density, and predictable panel behaviour. Provide meaningful selected, active, disabled, hover, focus, resizing, collapsing, and keyboard states where relevant.

Do not turn every tool into a large card. Keep frequent actions reachable and infrequent actions discoverable. Avoid decorative spacing that wastes workspace.

## 15. Forms and input controls

- Use the correct input type and label every field.
- Explain validation and constraints before or at the point they matter.
- Preserve valid user input when an error occurs.
- Disable submit actions only when the reason is clear; show progress during submission.
- Prevent accidental duplicate submissions where relevant.
- Make errors specific and actionable, and provide success confirmation.
- Do not use arbitrary outlined boxes or decorative borders as a substitute for hierarchy.

## 16. Interaction states and behaviour

Every interactive element needs coherent default, hover, focus-visible, active, selected, disabled, loading, success, and error states as applicable. A control that looks interactive must perform the action its label implies. Do not ship dead buttons, fake links, decorative toggles, or controls with no meaningful feedback.

Use confirmation for consequential or destructive actions. Support undo or recovery when feasible. Avoid blocking users with unnecessary confirmations for reversible, low-impact actions.

## 17. Empty, loading, error, and recovery states

Design these states as part of the feature, not as afterthoughts. Loading should indicate progress without unnecessary layout jumps. Empty states should explain the situation and offer a relevant next step. Errors should preserve user work where possible and support retry, correction, or an alternate path. Do not show infinite spinners without a timeout or recovery path.

## 18. Dialogs and overlays

Use a dialog only when the user must focus on a bounded task or decision. Keep content and actions focused. Make close behaviour clear, trap and restore focus correctly where appropriate, support Escape when safe, and avoid nested modal stacks. Destructive actions must name the consequence clearly.

## 19. Tables and dense information

Use tables for genuinely comparative or tabular data, with clear headers, aligned values, suitable density, and responsive handling. Use lists for sequential or non-tabular content. Do not squeeze tables into tiny cards or hide essential data without a discoverable alternative. Sortable headers and row actions must be functional and accessible.

## 20. Responsive design and orientation

Support mobile, tablet, laptop, desktop, ultrawide, portrait, and landscape layouts. Do not treat responsiveness as merely shrinking desktop elements. Recompose navigation, content order, controls, tables, and panels intentionally for smaller screens.

Test actual rendered screens at multiple viewports and orientations. Fix overflow, clipping, overlap, unreadable text, unreachable controls, and accidental horizontal scrolling. Account for safe areas where relevant. Do not claim responsive support based only on CSS breakpoints or a successful build.

## 21. Accessibility

Use semantic elements, sensible heading order, labels, accessible names, sufficient contrast, visible keyboard focus, keyboard-operable controls, and appropriate ARIA only where native semantics are insufficient. Do not use ARIA to disguise incorrect HTML. Respect reduced-motion preferences. Check accessibility with automated tools and manual keyboard review; automated scans do not guarantee accessibility.

## 22. Motion

Use motion only when it clarifies state, spatial relationships, or feedback. Keep transitions brief and purposeful. Avoid decorative animation, excessive parallax, bouncing, and motion that delays interaction. Respect reduced-motion settings and avoid layout shifts.

## 23. Trust and content accuracy

Never fabricate business facts, customer proof, ratings, reviews, legal assurances, security claims, pricing, or availability. Make destructive, financial, privacy, and permission-related consequences explicit. Do not misrepresent a simulated state as a completed external action.

## 24. Performance-aware design

Use appropriately sized and compressed images, lazy-load non-critical media, avoid unnecessary dependencies, and prevent large layout shifts. Complex visual effects and oversized assets must justify their performance cost. Test on realistic slower devices and networks where practical.

## 25. Implementation quality

- Follow the repository's language, framework, architecture, linting, formatting, and naming conventions.
- Prefer small, reusable, well-scoped components and semantic IDs/classes.
- Use Flexbox by default rather than CSS Grid unless explicitly approved.
- Keep business logic out of presentation where the project architecture supports separation.
- Avoid duplicate styles, conflicting overrides, dead code, unexplained magic values, and unnecessary dependencies.
- Do not use raw colour values when semantic tokens exist. Do not introduce a new token without approval.
- Do not rewrite unrelated files or refactor unrelated systems to complete a focused task.
- Handle slow networks, failed requests, retries, and recoverable errors where relevant.

## 26. Protect existing functionality

Before editing, understand the current user journeys and identify regressions the change could cause. Preserve existing behaviour unless the request explicitly changes it. Do not remove working features, data, routes, tests, or integrations to make the new task easier. Add or update tests for the changed behaviour.

## 27. Verification gates

A task is not complete until applicable gates pass:

1. **Code inspection:** review the diff, architecture, styling, and component reuse.
2. **Static checks:** run lint, type checks, tests, build, and Design Guard.
3. **Browser checks:** test relevant routes across configured sizes and orientations.
4. **Visual review:** inspect captured screenshots, not just the desktop viewport.
5. **Interaction review:** exercise the main task, validation, loading, empty, failure, success, and recovery states.
6. **Accessibility review:** run axe or equivalent plus keyboard and focus checks.
7. **Regression review:** confirm existing routes and core features still work.

Fix failures before declaring completion. Do not lower a rule's severity, suppress a finding, delete a test, or weaken the acceptance criteria merely to obtain a green result.

## 28. Research and visual review evidence

Record the references consulted, the design decisions they informed, the viewports tested, the user journey exercised, and any known limitations. Keep evidence factual and concise. A screenshot is evidence of a rendered state, not proof of good design by itself.

## 29. Rejection protocol

Reject an implementation and revise it when it contains unjustified generic cards or sections, arbitrary colour or typography, poor page-specific structure, confusing controls, broken responsive behaviour, dead interactions, fabricated content, inaccessible workflows, or regressions. Explain the concrete issue and correct it; do not defend weak output with subjective claims.

## 30. Handling user feedback

Treat explicit design feedback as a constraint for the current task and future relevant work. Do not repeatedly reintroduce rejected patterns under different names. When a request appears to conflict with an existing rule, ask only if the conflict materially changes the result; otherwise follow the latest instruction.

## 31. Completion report

Report what changed, the important design decisions, tests actually run, responsive and accessibility checks completed, and any unresolved issues. Distinguish automated checks from manual review. Never claim that a test, browser journey, research step, or visual inspection was completed unless it actually was.

## Final principle

Do not optimize for the fastest way to generate a screen. Optimize for the clearest and most coherent way to help the user complete the task. Make every design decision intentional, and verify the result in the running product.
