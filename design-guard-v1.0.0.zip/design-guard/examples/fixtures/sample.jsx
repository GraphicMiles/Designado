export function Example() {
  return <main className="bento-grid"><p style={{ color: 'var(--color-primary)' }}>Example fixture</p></main>;
}
