import fs from 'node:fs/promises';
import path from 'node:path';
import postcss from 'postcss';
import { loadConfig } from './config.js';
let scssParser = null;
try { scssParser = (await import('postcss-scss')).default; } catch { /* optional parser; standard CSS parsing remains available */ }

const STYLE_EXTENSIONS = new Set(['.css', '.scss', '.pcss']);
const SOURCE_EXTENSIONS = new Set(['.js', '.jsx', '.ts', '.tsx', '.vue', '.svelte', '.html']);
const COLOR_LITERAL = /#[\da-f]{3,8}\b|\b(?:rgb|rgba|hsl|hsla|hwb)\([^)]*\)/gi;
const NAMED_COLORS = new Set(('aliceblue antiquewhite aqua aquamarine azure beige bisque black blanchedalmond blue blueviolet brown burlywood cadetblue chartreuse chocolate coral cornflowerblue cornsilk crimson cyan darkblue darkcyan darkgoldenrod darkgray darkgrey darkgreen darkkhaki darkmagenta darkolivegreen darkorange darkorchid darkred darksalmon darkseagreen darkslateblue darkslategray darkslategrey darkturquoise darkviolet deeppink deepskyblue dimgray dimgrey dodgerblue firebrick floralwhite forestgreen fuchsia gainsboro ghostwhite gold goldenrod gray grey green greenyellow honeydew hotpink indianred indigo ivory khaki lavender lavenderblush lawngreen lemonchiffon lightblue lightcoral lightcyan lightgoldenrodyellow lightgray lightgrey lightgreen lightpink lightsalmon lightseagreen lightskyblue lightslategray lightslategrey lightsteelblue lightyellow lime limegreen linen magenta maroon mediumaquamarine mediumblue mediumorchid mediumpurple mediumseagreen mediumslateblue mediumspringgreen mediumturquoise mediumvioletred midnightblue mintcream mistyrose moccasin navajowhite navy oldlace olive olivedrab orange orangered orchid palegoldenrod palegreen paleturquoise palevioletred papayawhip peachpuff peru pink plum powderblue purple rebeccapurple red rosybrown royalblue saddlebrown salmon sandybrown seagreen seashell sienna silver skyblue slateblue slategray slategrey snow springgreen steelblue tan teal thistle tomato turquoise violet wheat white whitesmoke yellow yellowgreen').split(' '));
const CARD_PATTERN = /\b(?:bento(?:-grid)?|card-grid|cards-grid|generic-card|stat-card|feature-card)\b/i;

export async function auditProject(configInput) {
  const config = typeof configInput === 'string' || !configInput ? await loadConfig(configInput) : configInput;
  const projectRoot = config.__projectRoot || process.cwd();
  const allFiles = await walkFiles(projectRoot);
  const files = allFiles
    .filter((file) => config.sourcePatterns.some((pattern) => matchGlob(pattern, file)))
    .filter((file) => !(config.exclude || []).some((pattern) => matchGlob(pattern, file)))
    .sort();
  const issues = [];
  if (files.length === 0) {
    issues.push(makeIssue(config, 'no-source-files', undefined, '<project>', 1, 'No files matched sourcePatterns. Update the config to include this project’s frontend source directories.'));
  }
  const fontFamilies = new Set();
  const rawColors = new Set();
  const gutterValues = new Map();
  const tokenFiles = new Set((config.tokenFiles || []).map((file) => normalizePath(file)));

  for (const file of files.sort()) {
    const absolutePath = path.resolve(config.__projectRoot || process.cwd(), file);
    let source;
    try {
      source = await fs.readFile(absolutePath, 'utf8');
    } catch (error) {
      issues.push(makeIssue(config, 'file-read-error', 'error', file, 1, `Could not read file: ${error.message}`));
      continue;
    }
    const extension = path.extname(file).toLowerCase();
    if (STYLE_EXTENSIONS.has(extension)) {
      auditStylesheet({ config, file, source, issues, fontFamilies, rawColors, gutterValues, isTokenFile: tokenFiles.has(normalizePath(file)) });
    } else if (SOURCE_EXTENSIONS.has(extension)) {
      auditSource({ config, file, source, issues, rawColors });
    }
  }

  if (fontFamilies.size > config.maxFontFamilies) {
    issues.push(makeIssue(config, 'too-many-font-families', undefined, '<project>', 1,
      `Found ${fontFamilies.size} font families (${[...fontFamilies].join(', ')}); the configured maximum is ${config.maxFontFamilies}.`));
  }
  const repeatedThreshold = 4;
  for (const [value, selectors] of gutterValues) {
    if (selectors.size >= repeatedThreshold) {
      issues.push(makeIssue(config, 'repeated-horizontal-gutter', undefined, '<project>', 1,
        `The same horizontal padding (${value}) appears on ${selectors.size} selectors. Check that nested wrappers are not creating repeated gutters. This is a heuristic, not an automatic violation.`));
    }
  }
  if (config.approvedColors.length > config.maxPaletteColors) {
    issues.push(makeIssue(config, 'palette-size', 'error', '<config>', 1,
      `The approved palette has ${config.approvedColors.length} colours; the maximum is ${config.maxPaletteColors}.`));
  }

  const filteredIssues = applySuppressions(issues.filter((issue) => issue.severity !== 'off'), config.suppressions || []);
  return {
    projectName: config.projectName,
    filesScanned: files.length,
    fontFamilies: [...fontFamilies].sort(),
    rawColorsFound: [...rawColors].sort(),
    issues: filteredIssues,
    summary: summarize(filteredIssues)
  };
}


async function walkFiles(root, relative = '') {
  const directory = path.join(root, relative);
  let entries;
  try {
    entries = await fs.readdir(directory, { withFileTypes: true });
  } catch {
    return [];
  }
  const files = [];
  for (const entry of entries) {
    const childRelative = path.posix.join(relative.replace(/\\/g, '/'), entry.name);
    if (entry.isDirectory()) {
      if (['.git', 'node_modules', 'dist', 'build', '.next', 'coverage', '.turbo', '.vercel'].includes(entry.name)) continue;
      files.push(...await walkFiles(root, childRelative));
    } else if (entry.isFile()) {
      files.push(childRelative);
    }
  }
  return files;
}

function matchGlob(pattern, file) {
  const normalized = normalizePath(pattern);
  const expanded = expandBraces(normalized);
  return expanded.some((item) => globRegex(item).test(normalizePath(file)));
}

function expandBraces(pattern) {
  const match = pattern.match(/\{([^{}]+)\}/);
  if (!match) return [pattern];
  return match[1].split(',').flatMap((part) => expandBraces(pattern.replace(match[0], part)));
}

function globRegex(pattern) {
  let source = '^';
  for (let index = 0; index < pattern.length; index += 1) {
    const char = pattern[index];
    const next = pattern[index + 1];
    if (char === '*' && next === '*') {
      if (pattern[index + 2] === '/') {
        source += '(?:.*/)?';
        index += 2;
      } else {
        source += '.*';
        index += 1;
      }
    } else if (char === '*') source += '[^/]*';
    else if (char === '?') source += '[^/]';
    else if ('.^$+()|{}[]\\'.includes(char)) source += '\\' + char;
    else source += char;
  }
  return new RegExp(`${source}$`);
}

function auditStylesheet({ config, file, source, issues, fontFamilies, rawColors, gutterValues, isTokenFile }) {
  let root;
  try {
    const parser = path.extname(file).toLowerCase() === '.scss' ? scssParser : undefined;
    root = postcss.parse(source, { from: file, parser: parser || undefined });
  } catch (error) {
    issues.push(makeIssue(config, 'css-parse-error', undefined, file, error.line || 1, error.reason || error.message));
    return;
  }

  root.walkDecls((decl) => {
    const prop = decl.prop.toLowerCase();
    const value = decl.value.trim();
    const normalizedValue = value.toLowerCase();
    const line = decl.source?.start?.line || 1;

    if ((prop === 'display' && /\bgrid\b/i.test(value)) || prop.startsWith('grid-')) {
      issues.push(makeIssue(config, 'no-css-grid', undefined, file, line,
        `CSS Grid declaration "${decl.toString()}" found. Use Flexbox or another layout method unless this project explicitly authorizes Grid.`));
    }
    if (/\b(?:linear|radial|conic)-gradient\s*\(/i.test(value)) {
      issues.push(makeIssue(config, 'no-gradients', undefined, file, line, `Gradient detected in ${prop}.`));
    }
    if (prop === 'backdrop-filter' || prop === '-webkit-backdrop-filter') {
      issues.push(makeIssue(config, 'no-glassmorphism', undefined, file, line, 'Backdrop blur/filter detected. Avoid glassmorphism and decorative blur surfaces.'));
    }
    if (prop === 'box-shadow' && normalizedValue !== 'none') {
      issues.push(makeIssue(config, 'no-decorative-shadows', undefined, file, line, 'Box shadow detected. Use elevation only when it communicates a real interaction or hierarchy, and document an approved exception.'));
    }
    if (prop === 'text-shadow' && normalizedValue !== 'none') {
      issues.push(makeIssue(config, 'no-glow-effects', undefined, file, line, 'Text shadow detected; remove decorative glow effects.'));
    }
    if (prop === 'filter' && /(?:drop-shadow|blur)\s*\(/i.test(value)) {
      issues.push(makeIssue(config, 'no-glow-effects', undefined, file, line, 'Decorative drop-shadow or blur filter detected; remove it unless explicitly approved for a functional purpose.'));
    }
    if (!isTokenFile && /^(?:padding-inline|padding-left|padding-right)$/.test(prop)) {
      const key = value.replace(/\s+/g, ' ').toLowerCase();
      if (!gutterValues.has(key)) gutterValues.set(key, new Set());
      gutterValues.get(key).add(decl.parent?.selector || '<unknown selector>');
    }
    if (prop === 'font-family') {
      for (const family of parseFontFamilies(value)) {
        fontFamilies.add(family);
        if (!config.allowedFontFamilies.some((allowed) => allowed.toLowerCase() === family.toLowerCase())) {
          issues.push(makeIssue(config, 'font-family-not-approved', undefined, file, line,
            `Font family "${family}" is not in allowedFontFamilies. Approve it in configuration or use the established project typography.`));
        }
      }
    }
    if (!isTokenFile) {
      const literals = value.match(COLOR_LITERAL) || [];
      if (isColorDeclaration(prop)) literals.push(...findNamedColors(value));
      for (const literal of literals) {
        const normalized = normalizeColor(literal);
        rawColors.add(normalized);
        const approved = config.approvedColors.some((color) => normalizeColor(color) === normalized);
        if (!approved) {
          issues.push(makeIssue(config, 'no-unapproved-color-literals', undefined, file, line,
            `Unapproved colour literal "${literal}". Use an approved design token or add the colour to approvedColors after design approval.`));
        }
      }
    }
  });
}

function auditSource({ config, file, source, issues, rawColors }) {
  const lines = source.split(/\r?\n/);
  lines.forEach((lineText, index) => {
    const line = index + 1;
    const literals = lineText.match(COLOR_LITERAL) || [];
    for (const literal of literals) {
      const normalized = normalizeColor(literal);
      rawColors.add(normalized);
      if (!config.approvedColors.some((color) => normalizeColor(color) === normalized)) {
        issues.push(makeIssue(config, 'no-unapproved-color-literals', undefined, file, line,
          `Unapproved colour literal "${literal}" in source. Use a design token or approve it in configuration.`));
      }
    }
    if (/\bstyle\s*=\s*(?:\{\s*\{|"|')/.test(lineText)) {
      issues.push(makeIssue(config, 'inline-styles', undefined, file, line,
        'Inline styling detected. Prefer the project styling system so design rules remain centralized. Review whether this is genuinely dynamic or avoidable.'));
    }
    const classFragments = [...lineText.matchAll(/(?:class|className)\s*=\s*["'`]([^"'`]*)["'`]/g)].map((match) => match[1]);
    const componentPatternFound = /<(?:Card|Bento)(?:\s|\/|>)/.test(lineText);
    for (const fragment of classFragments) {
      if (CARD_PATTERN.test(fragment)) {
        issues.push(makeIssue(config, 'suspicious-card-pattern', undefined, file, line,
          `Card/Bento-style class pattern "${fragment}" found. This is a review prompt, not a ban: verify that the card is appropriate to the content and user task.`));
      }
    }
    if (componentPatternFound) {
      issues.push(makeIssue(config, 'suspicious-card-pattern', undefined, file, line,
        'A generic Card/Bento component is used. Verify that the content is an independent unit that genuinely benefits from this treatment.'));
    }
  });
}

function isColorDeclaration(prop) {
  return prop === 'color' || prop === 'background' || prop === 'background-image' || prop === 'border' ||
    prop.startsWith('border-') || prop.startsWith('outline') || prop === 'fill' || prop === 'stroke' ||
    prop === 'text-decoration' || prop.endsWith('-color');
}

function findNamedColors(value) {
  const pattern = new RegExp(`(?:^|[\\s,(])(${[...NAMED_COLORS].join('|')})(?=$|[\\s),])`, 'gi');
  return [...value.matchAll(pattern)].map((match) => match[1]);
}

function parseFontFamilies(value) {
  const genericFamilies = new Set(['serif', 'sans-serif', 'monospace', 'system-ui', 'ui-sans-serif', 'ui-serif', 'ui-monospace', 'cursive', 'fantasy', 'inherit', 'initial', 'revert']);
  return value.split(',')
    .map((family) => family.trim().replace(/^['"]|['"]$/g, '').trim())
    .filter((family) => family && !genericFamilies.has(family.toLowerCase()));
}

function normalizeColor(color) {
  return color.replace(/\s+/g, '').toLowerCase();
}

function normalizePath(file) {
  return file.replace(/\\/g, '/').replace(/^\.\//, '');
}

function makeIssue(config, rule, explicitSeverity, file, line, message) {
  return {
    rule,
    severity: explicitSeverity || config.rules[rule] || 'warning',
    file,
    line,
    message
  };
}

function applySuppressions(issues, suppressions) {
  return issues.filter((issue) => !suppressions.some((suppression) => {
    if (suppression.rule !== issue.rule) return false;
    if (suppression.file && suppression.file !== issue.file) return false;
    if (suppression.filePattern && !globLike(suppression.filePattern, issue.file)) return false;
    if (!suppression.reason || suppression.reason.trim().length < 8) return false;
    if (suppression.expires && new Date(suppression.expires).getTime() < Date.now()) return false;
    return true;
  }));
}

function globLike(pattern, file) {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '§').replace(/\*/g, '[^/]*').replace(/§/g, '.*').replace(/\?/g, '.');
  return new RegExp(`^${escaped}$`).test(file);
}

function summarize(issues) {
  const summary = { errors: 0, warnings: 0, total: issues.length, byRule: {} };
  for (const issue of issues) {
    if (issue.severity === 'error') summary.errors += 1;
    else if (issue.severity === 'warning') summary.warnings += 1;
    summary.byRule[issue.rule] = (summary.byRule[issue.rule] || 0) + 1;
  }
  return summary;
}
