import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';

export async function auditBrowser(config, options = {}) {
  const baseUrl = options.url || config.browser.baseUrl;
  if (!baseUrl) throw new Error('Set browser.baseUrl in the config or pass --url.');

  const projectRequire = createRequire(path.join(process.cwd(), 'package.json'));
  let chromium;
  let AxeBuilder;
  try {
    ({ chromium } = projectRequire('playwright'));
    const axeModule = projectRequire('@axe-core/playwright');
    AxeBuilder = axeModule.default || axeModule;
  } catch {
    throw new Error('Browser checks require Playwright and axe-core. Install them in the target project with: npm install --save-dev playwright @axe-core/playwright, then install a browser with: npx playwright install chromium');
  }

  const screenshotRoot = path.resolve(process.cwd(), config.browser.screenshotsDir);
  await fs.mkdir(screenshotRoot, { recursive: true });
  const results = [];
  let browser;
  try {
    browser = await chromium.launch({ headless: true });
  } catch (error) {
    throw new Error(`Could not launch Chromium. Run \"npx playwright install chromium\" in the target project. Details: ${error.message}`);
  }

  try {
    for (const route of config.browser.paths) {
      for (const viewport of config.browser.viewports) {
        const page = await browser.newPage({ viewport: { width: viewport.width, height: viewport.height } });
        const pageErrors = [];
        page.on('pageerror', (error) => pageErrors.push(error.message));
        const targetUrl = new URL(route, ensureTrailingSlash(baseUrl)).toString();
        const result = {
          route,
          url: targetUrl,
          viewport: { ...viewport },
          screenshot: null,
          horizontalOverflow: false,
          documentWidth: null,
          viewportWidth: viewport.width,
          pageErrors,
          axeViolations: [],
          navigationError: null
        };

        try {
          await page.goto(targetUrl, { waitUntil: config.browser.waitUntil || 'domcontentloaded', timeout: 45000 });
          const dimensions = await page.evaluate(() => ({
            documentWidth: Math.max(document.documentElement.scrollWidth, document.body?.scrollWidth || 0),
            viewportWidth: window.innerWidth,
            documentHeight: Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0)
          }));
          result.documentWidth = dimensions.documentWidth;
          result.viewportWidth = dimensions.viewportWidth;
          result.documentHeight = dimensions.documentHeight;
          result.horizontalOverflow = dimensions.documentWidth > dimensions.viewportWidth + (config.browser.overflowTolerance ?? 2);

          const screenshotName = `${slug(route)}--${slug(viewport.name)}.png`;
          const screenshotPath = path.join(screenshotRoot, screenshotName);
          await page.screenshot({ path: screenshotPath, fullPage: true, animations: 'disabled' });
          result.screenshot = path.relative(process.cwd(), screenshotPath).replace(/\\/g, '/');

          const axeResults = await new AxeBuilder({ page })
            .withTags(config.browser.axeTags || ['wcag2a', 'wcag2aa'])
            .analyze();
          result.axeViolations = axeResults.violations.map((violation) => ({
            id: violation.id,
            impact: violation.impact || 'unknown',
            description: violation.description,
            help: violation.help,
            helpUrl: violation.helpUrl,
            nodes: violation.nodes.slice(0, 8).map((node) => ({
              target: node.target,
              summary: node.failureSummary
            }))
          }));
        } catch (error) {
          result.navigationError = error.message;
        } finally {
          await page.close();
        }
        results.push(result);
      }
    }
  } finally {
    await browser.close();
  }

  const report = {
    projectName: config.projectName,
    baseUrl,
    generatedAt: new Date().toISOString(),
    results,
    summary: summarizeBrowser(results, config)
  };
  const reportPath = path.resolve(process.cwd(), config.browser.resultsFile);
  await fs.mkdir(path.dirname(reportPath), { recursive: true });
  await fs.writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`, 'utf8');
  const reviewPath = path.resolve(process.cwd(), '.design-guard/VISUAL-REVIEW.md');
  await fs.mkdir(path.dirname(reviewPath), { recursive: true });
  await fs.writeFile(reviewPath, buildVisualReview(report), 'utf8');
  report.reportFile = path.relative(process.cwd(), reportPath).replace(/\\/g, '/');
  report.visualReviewFile = path.relative(process.cwd(), reviewPath).replace(/\\/g, '/');
  return report;
}

function summarizeBrowser(results, config) {
  let overflows = 0;
  let navigationErrors = 0;
  let pageErrors = 0;
  let blockingAxeViolations = 0;
  let allAxeViolations = 0;
  for (const result of results) {
    if (result.horizontalOverflow) overflows += 1;
    if (result.navigationError) navigationErrors += 1;
    pageErrors += result.pageErrors.length;
    allAxeViolations += result.axeViolations.length;
    blockingAxeViolations += result.axeViolations.filter((violation) => (config.browser.failOnAxeImpact || ['critical', 'serious']).includes(violation.impact)).length;
  }
  return { runs: results.length, overflows, navigationErrors, pageErrors, allAxeViolations, blockingAxeViolations };
}

function buildVisualReview(report) {
  const lines = [
    '# Manual visual review',
    '',
    `Project: ${report.projectName}`,
    `Generated: ${report.generatedAt}`,
    '',
    '> Automated browser checks cannot determine whether a layout is purposeful, attractive, coherent, or appropriate to its page type. An agent or reviewer must inspect every screenshot below.',
    '',
    '## Screenshot matrix',
    ''
  ];
  for (const result of report.results) {
    lines.push(`### ${result.route} · ${result.viewport.name} (${result.viewport.width}×${result.viewport.height})`);
    lines.push(`- Screenshot: \`${result.screenshot || 'not captured'}\``);
    lines.push(`- Horizontal overflow: ${result.horizontalOverflow ? 'FAIL' : 'PASS'}`);
    lines.push(`- Navigation: ${result.navigationError ? `FAIL — ${result.navigationError}` : 'completed'}`);
    lines.push(`- Page errors: ${result.pageErrors.length}`);
    lines.push(`- Accessibility violations: ${result.axeViolations.length}`);
    lines.push('');
  }
  lines.push('## Reviewer checklist', '');
  for (const item of [
    'The page structure matches its purpose; legal/documentation pages are treated as documents, not product showcases.',
    'No arbitrary Bento layout, generic cards, or sections have been added without a clear user or content need.',
    'Spacing and page gutters are intentional; nested wrappers do not create repetitive padding.',
    'Colour is consistent with approved semantic tokens; no orphan or one-off colours appear.',
    'Typography has a clear hierarchy and uses no more than the approved font families.',
    'Navigation, menus, dropdowns, forms, dialogs, tables, and controls are correctly sized and understandable.',
    'Every visible control has a meaningful action and appropriate hover, focus, active, disabled, loading, success, and error states where relevant.',
    'Mobile and tablet layouts are intentionally composed, not merely squeezed desktop layouts.',
    'Text remains readable; no clipping, overlap, awkward wrapping, or accidental horizontal scrolling exists.',
    'Images and icons are relevant, consistent, correctly proportioned, and accessible.',
    'The most important user journey has been completed end-to-end using realistic test data.',
    'The design is consistent with the researched references without copying them blindly.'
  ]) lines.push(`- [ ] ${item}`);
  lines.push('', '## Decision', '', '- [ ] PASS — all automated and manual checks resolved.', '- [ ] FAIL — violations remain; list them below.', '', 'Reviewer notes:', '');
  return `${lines.join('\n')}\n`;
}

function ensureTrailingSlash(value) {
  return value.endsWith('/') ? value : `${value}/`;
}

function slug(value) {
  return value.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').toLowerCase() || 'root';
}
