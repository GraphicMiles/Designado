import fs from 'node:fs/promises';
import path from 'node:path';
import { auditProject } from './audit.js';
import { auditBrowser } from './browser.js';
import { writeDefaultConfig, loadConfig } from './config.js';

const HELP = `Design Guard — reusable UI design and implementation checks

Usage:
  design-guard init [--config path]
  design-guard audit [--config path] [--json] [--fail-on warning|error]
  design-guard browser [--config path] [--url http://localhost:3000]
  design-guard check [--config path] [--browser] [--url http://localhost:3000]

Commands:
  init      Create a project configuration and review checklist.
  audit     Scan source files for configured design-rule violations.
  browser   Capture responsive screenshots and run axe accessibility checks.
  check     Run the static audit; add --browser to run browser checks too.

Exit codes: 0 = pass, 1 = rule violations, 2 = setup/runtime failure.
`;

export async function run(args) {
  const [command, ...rest] = args;
  const options = parseOptions(rest);
  if (!command || command === 'help' || options.help) {
    console.log(HELP);
    return;
  }

  if (command === 'init') {
    const configPath = await writeDefaultConfig(options.config || 'design-guard.config.json');
    const reviewPath = path.resolve('DESIGN-REVIEW.md');
    try {
      await fs.access(reviewPath);
      console.log(`Created ${configPath}. Existing ${reviewPath} was left untouched.`);
    } catch {
      await fs.writeFile(reviewPath, defaultReviewTemplate(), 'utf8');
      console.log(`Created ${configPath} and ${reviewPath}.`);
    }
    console.log('Next: edit approvedColors, sourcePatterns, browser.baseUrl and browser.paths for this project.');
    return;
  }

  const config = await loadConfig(options.config);
  if (command === 'audit' || command === 'check') {
    const report = await auditProject(config);
    const reportPath = path.resolve('.design-guard/static-report.json');
    await fs.mkdir(path.dirname(reportPath), { recursive: true });
    await fs.writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`, 'utf8');
    if (options.json) console.log(JSON.stringify(report, null, 2));
    else printStaticReport(report, reportPath);
    let failed = isFailure(report, options.failOn || 'error');

    if (command === 'check' && options.browser) {
      const browserReport = await auditBrowser(config, { url: options.url });
      printBrowserReport(browserReport);
      if (browserReport.summary.overflows || browserReport.summary.navigationErrors || browserReport.summary.pageErrors || browserReport.summary.blockingAxeViolations) failed = true;
      if (options.json) console.log(JSON.stringify(browserReport, null, 2));
    }
    if (failed) process.exitCode = 1;
    return;
  }

  if (command === 'browser') {
    const report = await auditBrowser(config, { url: options.url });
    printBrowserReport(report);
    const summary = report.summary;
    if (summary.overflows || summary.navigationErrors || summary.pageErrors || summary.blockingAxeViolations) process.exitCode = 1;
    return;
  }

  console.error(`Unknown command: ${command}\n`);
  console.log(HELP);
  process.exitCode = 2;
}

function parseOptions(args) {
  const result = {};
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (arg === '--help' || arg === '-h') result.help = true;
    else if (arg === '--json') result.json = true;
    else if (arg === '--browser') result.browser = true;
    else if (['--config', '--url', '--fail-on'].includes(arg)) {
      const value = args[index + 1];
      if (!value || value.startsWith('--')) throw new Error(`${arg} requires a value.`);
      result[arg.slice(2).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase())] = value;
      index += 1;
    } else throw new Error(`Unknown option: ${arg}`);
  }
  if (result.failOn && !['warning', 'error'].includes(result.failOn)) throw new Error('--fail-on must be warning or error.');
  return result;
}

function isFailure(report, failOn) {
  return report.issues.some((issue) => issue.severity === 'error' || (failOn === 'warning' && issue.severity === 'warning'));
}

function printStaticReport(report, reportPath) {
  console.log(`\nDesign Guard · ${report.projectName}`);
  console.log(`Scanned ${report.filesScanned} files. Fonts found: ${report.fontFamilies.length ? report.fontFamilies.join(', ') : 'none detected'}.`);
  console.log(`Errors: ${report.summary.errors} | Warnings: ${report.summary.warnings}`);
  for (const issue of report.issues) {
    const location = `${issue.file}:${issue.line}`;
    console.log(`${issue.severity.toUpperCase()} [${issue.rule}] ${location} — ${issue.message}`);
  }
  if (!report.issues.length) console.log('No configured static violations found.');
  console.log(`Report: ${path.relative(process.cwd(), reportPath).replace(/\\/g, '/')}`);
  console.log('Note: static checks do not certify design quality; inspect browser screenshots and complete the manual review.');
}

function printBrowserReport(report) {
  const summary = report.summary;
  console.log(`\nBrowser checks · ${report.projectName}`);
  console.log(`Runs: ${summary.runs} | Overflows: ${summary.overflows} | Navigation errors: ${summary.navigationErrors} | Page errors: ${summary.pageErrors} | Blocking accessibility violations: ${summary.blockingAxeViolations}`);
  console.log(`Screenshots: ${report.results.map((item) => item.screenshot).filter(Boolean).join(', ') || 'none captured'}`);
  console.log(`Visual review: ${report.visualReviewFile}`);
}

function defaultReviewTemplate() {
  return `# Design review gate\n\nDo not mark a page complete because it compiles or looks acceptable at one viewport.\n\n- [ ] Page structure suits its purpose and content type.\n- [ ] No unjustified cards, Bento layouts, sections, or decorative elements.\n- [ ] Spacing, gutters, and content widths are intentional.\n- [ ] All colours use approved semantic tokens.\n- [ ] Typography follows the approved type system.\n- [ ] Navigation, menus, forms, and controls are understandable and functional.\n- [ ] Loading, empty, error, disabled, and success states are considered.\n- [ ] Mobile, tablet, desktop, ultrawide, and orientation changes are reviewed.\n- [ ] No clipping, overlap, or accidental horizontal overflow.\n- [ ] Accessibility and keyboard operation are checked.\n- [ ] The key user journey is tested end-to-end.\n- [ ] Existing functionality is preserved; unrelated refactors are avoided.\n\nDecision: [ ] PASS  [ ] FAIL\n\nUnresolved issues:\n`;
}
