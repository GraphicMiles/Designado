import fs from 'node:fs/promises';
import path from 'node:path';

export const CONFIG_NAME = 'design-guard.config.json';

export const DEFAULT_CONFIG = {
  projectName: 'My project',
  sourcePatterns: [
    'src/**/*.{css,scss,pcss,js,jsx,ts,tsx,vue,svelte,html}',
    'app/**/*.{css,scss,pcss,js,jsx,ts,tsx,vue,svelte,html}',
    'pages/**/*.{css,scss,pcss,js,jsx,ts,tsx,vue,svelte,html}',
    'components/**/*.{css,scss,pcss,js,jsx,ts,tsx,vue,svelte,html}'
  ],
  exclude: ['**/node_modules/**', '**/dist/**', '**/build/**', '**/.next/**', '**/coverage/**'],
  tokenFiles: [],
  approvedColors: [],
  primaryColors: [],
  maxPrimaryColors: 2,
  maxPaletteColors: 4,
  allowedFontFamilies: ['Manrope', 'Poppins', 'Space Grotesk', 'Inter'],
  maxFontFamilies: 2,
  rules: {
    'no-css-grid': 'error',
    'no-gradients': 'error',
    'no-glassmorphism': 'error',
    'no-decorative-shadows': 'error',
    'no-glow-effects': 'error',
    'no-unapproved-color-literals': 'error',
    'font-family-not-approved': 'error',
    'too-many-font-families': 'error',
    'suspicious-card-pattern': 'warning',
    'inline-styles': 'warning',
    'repeated-horizontal-gutter': 'warning',
    'css-parse-error': 'error',
    'no-source-files': 'error'
  },
  suppressions: [],
  browser: {
    baseUrl: 'http://localhost:3000',
    paths: ['/'],
    screenshotsDir: '.design-guard/screenshots',
    resultsFile: '.design-guard/browser-report.json',
    waitUntil: 'domcontentloaded',
    viewports: [
      { name: 'mobile', width: 375, height: 812 },
      { name: 'mobile-landscape', width: 812, height: 375 },
      { name: 'tablet', width: 768, height: 1024 },
      { name: 'tablet-landscape', width: 1024, height: 768 },
      { name: 'laptop', width: 1366, height: 768 },
      { name: 'desktop', width: 1920, height: 1080 },
      { name: 'ultrawide', width: 2560, height: 1080 }
    ],
    overflowTolerance: 2,
    axeTags: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'],
    failOnAxeImpact: ['critical', 'serious']
  }
};

export async function loadConfig(configPath) {
  const resolved = path.resolve(configPath || CONFIG_NAME);
  let raw;
  try {
    raw = await fs.readFile(resolved, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') {
      throw new Error(`Could not find ${resolved}. Run "design-guard init" first or pass --config.`);
    }
    throw error;
  }
  let userConfig;
  try {
    userConfig = JSON.parse(raw);
  } catch (error) {
    throw new Error(`Invalid JSON in ${resolved}: ${error.message}`);
  }
  const config = mergeConfig(DEFAULT_CONFIG, userConfig);
  config.__configPath = resolved;
  config.__projectRoot = process.cwd();
  validateConfig(config);
  return config;
}

export async function writeDefaultConfig(destination = CONFIG_NAME) {
  const resolved = path.resolve(destination);
  try {
    await fs.access(resolved);
    throw new Error(`${resolved} already exists; refusing to overwrite it.`);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  await fs.writeFile(resolved, `${JSON.stringify(DEFAULT_CONFIG, null, 2)}\n`, 'utf8');
  return resolved;
}

function mergeConfig(base, override) {
  const result = structuredClone(base);
  for (const [key, value] of Object.entries(override || {})) {
    if (value && typeof value === 'object' && !Array.isArray(value) && result[key] && typeof result[key] === 'object' && !Array.isArray(result[key])) {
      result[key] = { ...result[key], ...value };
    } else {
      result[key] = value;
    }
  }
  return result;
}

function validateConfig(config) {
  if (!Array.isArray(config.sourcePatterns) || !config.sourcePatterns.length) {
    throw new Error('sourcePatterns must be a non-empty array of glob patterns.');
  }
  if (!Array.isArray(config.approvedColors) || !Array.isArray(config.allowedFontFamilies) || !Array.isArray(config.primaryColors)) {
    throw new Error('approvedColors, primaryColors, and allowedFontFamilies must be arrays.');
  }
  if ([...config.approvedColors, ...config.primaryColors, ...config.allowedFontFamilies].some((value) => typeof value !== 'string' || !value.trim())) {
    throw new Error('Colour and font allowlist entries must be non-empty strings.');
  }
  if (!Number.isInteger(config.maxPaletteColors) || !Number.isInteger(config.maxPrimaryColors) || !Number.isInteger(config.maxFontFamilies) || config.maxPaletteColors < 1 || config.maxPrimaryColors < 1 || config.maxFontFamilies < 1) {
    throw new Error('Palette and font maximums must be positive integers.');
  }
  if (!config.rules || typeof config.rules !== 'object' || Array.isArray(config.rules)) {
    throw new Error('rules must be an object mapping rule IDs to off, warning, or error.');
  }
  if (!Array.isArray(config.suppressions) || !Array.isArray(config.browser.paths) || !config.browser.paths.length || !Array.isArray(config.browser.viewports) || !config.browser.viewports.length) {
    throw new Error('suppressions, browser.paths, and browser.viewports must be arrays; browser.paths and browser.viewports cannot be empty.');
  }
  if (config.approvedColors.length > config.maxPaletteColors) {
    throw new Error(`approvedColors contains ${config.approvedColors.length} entries, exceeding maxPaletteColors (${config.maxPaletteColors}).`);
  }
  if (config.primaryColors.length > config.maxPrimaryColors) {
    throw new Error(`primaryColors contains ${config.primaryColors.length} entries, exceeding maxPrimaryColors (${config.maxPrimaryColors}).`);
  }
  for (const suppression of config.suppressions) {
    if (!suppression.rule || !suppression.reason || suppression.reason.trim().length < 8 || (!suppression.file && !suppression.filePattern)) {
      throw new Error('Each suppression requires rule, file or filePattern, and a reason of at least eight characters.');
    }
    if (suppression.expires && !Number.isFinite(Date.parse(suppression.expires))) {
      throw new Error(`Invalid suppression expiry date: ${suppression.expires}`);
    }
  }
  for (const [rule, severity] of Object.entries(config.rules)) {
    if (!['off', 'warning', 'error'].includes(severity)) {
      throw new Error(`Invalid severity "${severity}" for rule "${rule}". Use off, warning, or error.`);
    }
  }
}
