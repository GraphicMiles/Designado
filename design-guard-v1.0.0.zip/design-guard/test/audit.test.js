import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { auditProject } from '../src/audit.js';
import { DEFAULT_CONFIG } from '../src/config.js';

async function withProject(files, callback) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'design-guard-'));
  try {
    for (const [name, content] of Object.entries(files)) {
      const target = path.join(root, name);
      await fs.mkdir(path.dirname(target), { recursive: true });
      await fs.writeFile(target, content, 'utf8');
    }
    await callback(root);
  } finally {
    await fs.rm(root, { recursive: true, force: true });
  }
}

test('detects grid, gradients, unapproved colours, and font violations', async () => {
  await withProject({
    'src/page.css': `.grid { display: grid; color: #ff00ff; border: 1px solid red; background: linear-gradient(red, blue); font-family: Arial, sans-serif; }`
  }, async (root) => {
    const config = {
      ...structuredClone(DEFAULT_CONFIG),
      __projectRoot: root,
      sourcePatterns: ['src/**/*.css'],
      tokenFiles: [],
      approvedColors: [],
      allowedFontFamilies: ['Manrope', 'Inter']
    };
    const report = await auditProject(config);
    const rules = new Set(report.issues.map((issue) => issue.rule));
    assert.ok(rules.has('no-css-grid'));
    assert.ok(rules.has('no-gradients'));
    assert.ok(rules.has('no-unapproved-color-literals'));
    assert.ok(report.issues.some((issue) => issue.message.includes('red')), 'named CSS colour should be detected');
    assert.ok(rules.has('font-family-not-approved'));
    assert.equal(report.filesScanned, 1);
  });
});

test('does not flag token files or CSS variable references as raw colour literals', async () => {
  await withProject({
    'src/tokens.css': `:root { --brand: #123456; }`,
    'src/page.css': `.page { color: var(--brand); font-family: Manrope, sans-serif; }`
  }, async (root) => {
    const config = {
      ...structuredClone(DEFAULT_CONFIG),
      __projectRoot: root,
      sourcePatterns: ['src/**/*.css'],
      tokenFiles: ['src/tokens.css'],
      approvedColors: [],
      allowedFontFamilies: ['Manrope']
    };
    const report = await auditProject(config);
    assert.equal(report.issues.filter((issue) => issue.rule === 'no-unapproved-color-literals').length, 0);
    assert.deepEqual(report.fontFamilies, ['Manrope']);
  });
});


test('honours disabled rules and errors when source patterns match nothing', async () => {
  await withProject({ 'src/page.css': '.layout { display: grid; }' }, async (root) => {
    const config = {
      ...structuredClone(DEFAULT_CONFIG),
      __projectRoot: root,
      sourcePatterns: ['src/**/*.css'],
      rules: { ...DEFAULT_CONFIG.rules, 'no-css-grid': 'off' }
    };
    const report = await auditProject(config);
    assert.equal(report.issues.some((issue) => issue.rule === 'no-css-grid'), false);
  });
  await withProject({}, async (root) => {
    const config = { ...structuredClone(DEFAULT_CONFIG), __projectRoot: root, sourcePatterns: ['src/**/*.css'] };
    const report = await auditProject(config);
    assert.ok(report.issues.some((issue) => issue.rule === 'no-source-files' && issue.severity === 'error'));
  });
});
